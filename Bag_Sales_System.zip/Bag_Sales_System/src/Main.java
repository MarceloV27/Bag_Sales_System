public class Main {
    public static void main(String[] args) {


        PlasticBag plasticBag = new PlasticBag();
        plasticBag.setLength(70.0);
        plasticBag.setWidth(20.0);
        plasticBag.setTax(0.3);
        System.out.println(plasticBag.getTax());
        System.out.println(plasticBag.getPrice());

    }
}