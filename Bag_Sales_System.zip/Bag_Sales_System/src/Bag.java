public abstract class Bag {

    private double length;
    private double width;
    protected double price;
    public double getLength(){
        return length;
    }
    public void setLength(double length){
        this.length = length;
    }


    public double getWidth(){
        return width;
    }
    public void setWidth(double width){
        this.width = width;
    }
    public abstract double getPrice();
}
